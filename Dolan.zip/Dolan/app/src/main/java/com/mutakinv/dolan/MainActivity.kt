package com.mutakinv.dolan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mutakinv.dolan.ui.navigation.Screen
import com.mutakinv.dolan.ui.screen.about.AboutScreen
import com.mutakinv.dolan.ui.screen.detail.DetailScreen
import com.mutakinv.dolan.ui.screen.home.HomeScreen
import com.mutakinv.dolan.ui.theme.DolanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DolanApp()
        }
    }
}

@Composable
fun DolanApp(navController: NavHostController = rememberNavController()) {
    DolanTheme {
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    navigateToDetail = {
                        navController.navigate(Screen.Detail.createRoute(it))
                    },
                    navigateToAboutPage = {
                        navController.navigate(Screen.About.route)
                    },
                    onFavorite = {
                        // TODO::Add to favorite
                    },
                )
            }
            composable(Screen.Detail.route, arguments = listOf(
                navArgument("destinationId") {
                    type = NavType.StringType
                }
            )) {
                val id = it.arguments?.getString("destinationId") ?: "-1"
                DetailScreen(
                    destinationId = id,
                    navigateBack = { navController.navigateUp() }
                )
            }
            composable(Screen.About.route) {
                AboutScreen(navigateBack = {
                    navController.navigateUp()
                })
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun DefaultPreview() {
    DolanApp()
}