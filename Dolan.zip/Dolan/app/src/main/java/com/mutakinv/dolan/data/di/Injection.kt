package com.mutakinv.dolan.data.di

import com.mutakinv.dolan.data.repository.DestinationRepository


object Injection {
    fun provideRepository(): DestinationRepository {
        return DestinationRepository.getInstance()
    }
}