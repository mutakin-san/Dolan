package com.mutakinv.dolan.data.models

data class Destination(
    val id: String,
    val title: String,
    val imageUrl: String,
    val rating: Float,
    val location: String,
    val description: String,
    val price: Double
)