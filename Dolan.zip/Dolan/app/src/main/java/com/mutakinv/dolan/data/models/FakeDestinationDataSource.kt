package com.mutakinv.dolan.data.models

object FakeDestinationDataSource {
    val dummyDestinations = listOf(
        Destination(
            id = "1",
            title = "Finland",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2020/12/Oulanka-National-Park.jpg?resize=784%2c588",
            rating = 3.5f,
            location = "Finland",
            description = "In Lapland, in northern Finland, there are igloos, hotel rooms, and other accommodation options that were specially designed for enjoying the spectacular colorful natural light show known as the Aurora Borealis. Oulanka National Park is just one great spot in this region for viewing the dancing lights during the aurora sighting season, which falls in October and November as well as March and April. This magnificent park in the far north sits among a breathtaking rugged landscape of snow-covered forests with candle spruces standing frozen before a backdrop of the brilliant aurora. During the day, enjoy cross-country skiing, snow-shoeing, or even igloo building. Cozy log cabins located right in the park are ideal for laying your head down at night and make a great base to combine a vacation of winter sports with the chance to watch one of the greatest wonders of nature after dark",
            price = 15.0
        ),
        Destination(
            id = "2",
            title = "Dominica",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2016/10/Batibou-Beach.jpg?resize=784%2c588",
            rating = 4.0f,
            location = "Dominica",
            description = "Known as “The Nature Island of the Caribbean,” Dominica is an obvious choice for those who want to get back to nature. It has an incredibly lush landscape that includes volcanic hot springs, natural mud baths, countless rivers and waterfalls, unspoiled rain forest, and refreshing natural swimming holes. On Black Sand Beach, you can even visit a leatherback, hawksbill, and green turtle sanctuary. Dominica is also renowned for its whale watching opportunities, with a resident population of sperm whales that live just off the coast and are often visible from shore. The sheer underwater drop-offs around Dominica create deep, sheltered bays along the western coastline, making the perfect haven for divers to explore, and the sperm whale to breed and calve.",
            price = 25.0
        ),
        Destination(
            id = "3",
            title = "The Matterhorn - Zermatt, Switzerland",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2018/02/bigstock-193145596.jpg?resize=784%2c588",
            rating = 5.0f,
            location = "Switzerland",
            description = "The Swiss Alps offer some of Europe’s most dramatic natural scenery, with lush, green valleys dotted with colorful wildflowers that give way to spectacular snow-covered rocky peaks. Of course, the Matterhorn is its most famous peak, jutting into the sky like a 15,000-foot tall pyramid. The “Mountain of Mountains,” as it’s sometimes called, straddles the Swiss-Italian border, though its highest summit stands in Switzerland. It towers over the picturesque, car-free village of Zermatt, and if you aren’t up for climbing it, you can get to the top by riding a cable car that leads all the way to the summit, the highest scenic outlook platform in Europe.",
            price = 100.0
        ),
        Destination(
            id = "4",
            title = "Durmitor National Park, Montenegro",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2015/08/Durmitor-National-Park-Mon.jpg?resize=784%2c588",
            rating = 5.0f,
            location = "Montenegro",
            description = "This national park that covers the Durmitor Mountain Range and a narrow branch heading east along the Tara River offers absolutely jaw-dropping scenic beauty. The dramatic landscape, carved from limestone with ice and water over time, is home to nearly 50 peaks that tower over 6,500 feet in altitude. Three magnificent canyons can also be found here, including the wild Tara River, home to the deepest gorge in all of Europe, and rivers even flow under the park as well. Reach the high plateau by taking one of the numerous trails, three shelters are available for those who’d like to overnight: a hut, a refuge, and a bivouac. Be sure to visit the ice cave, filled with icy stalactites and stalagmites all year round – a perfect place for hikers to cool off, even in the middle of July, with cold water dripping from the ceiling.",
            price = 150.0
        ),
        Destination(
            id = "5",
            title = "Palau",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2016/07/bigstock-Beautiful-view-of-Palau-island-86974844.jpg?resize=784%2c588",
            rating = 5.0f,
            location = " Southern Lagoon of Palau",
            description = "This small collection of islands in the western Pacific Ocean boasts some of the best diving and snorkeling sites in the world. In 2005, the president declared the conservation of one-third of near-shore coastal waters and 20 percent of forest land by 2020. One of the best Pacific Islands to visit, these islands are also home to the first shark sanctuary in the world, a massive more than 231,661-square-kilometer area of protected space. The Rock Islands, which many became familiar with after watching “Survivor Palau,” are ancient relics of coral reefs that make up 300 islands in the Southern Lagoon of Palau. Most are uninhabited and are renowned for their unusual shape and fine, powdery sand beaches, but even more so for their azure-hued lagoons. The islands are also home to famed Jellyfish Lake, where millions of golden jellyfish live, harmless to humans, and a number of other surprises, like the Milky Way which is a bay filled with white limestone known for rejuvenating the skin.",
            price = 250.0
        ),
        Destination(
            id = "6",
            title = "Iceland",
            imageUrl = "https://i0.wp.com/files.tripstodiscover.com/files/2016/10/bigstock-Waterfall-Iceland-Seljaland-54698009-1.jpg?resize=784%2c588",
            rating = 5.0f,
            location = "Iceland",
            description = "Iceland is filled with spectacular natural attractions that make it one of the best places in the world for reconnecting with nature. There are countless waterfalls to gaze at, hot springs to soak in and caves to explore. Be sure to check out Seljalandsfoss, one of the nation’s most photographed falls. Located near the southern coast, it plummets nearly 200 feet into a pool below, and if you walk around to the back of the cascade, you can feel the spray of the water on your skin while enjoying a unique perspective that few others get to experience. Horseback riding, mountain biking, whale watching, sea kayaking and snorkeling are just a few of the other great ways to experience it.",
            price = 250.0
        ),
        Destination(
            id = "7",
            title = "Versailles Palace",
            imageUrl = "https://upload.wikimedia.org/wikipedia/commons/d/d2/Versailles-Chateau-Jardins02.jpg",
            rating = 4.0f,
            location = "France",
            description = "With more than 700 rooms, Versailles Palace is one of the largest in the world.  Famous for its royal occupants from King Louis XIV to Marie-Antoinette, the glittering Hall of Mirrors, lavishly decorated rooms, and priceless art, Versailles Palace gives you an unforgettable glimpse of royal life when you visit.  You can easily spend much or all of a day here.",
            price = 25.0
        ),
        Destination(
            id = "8",
            title = "Gatlinburg",
            imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Gatlinburg%2C_Tennessee_IMG_6598.tif/lossless-page1-1024px-Gatlinburg%2C_Tennessee_IMG_6598.tif.png",
            rating = 4.5f,
            location = "USA",
            description = "For a mountain getaway the whole family will enjoy, Gatlinburg, Tennessee, is an ideal destination. A massive aquarium, a mountain coaster and plenty of fun restaurants make this town a kid-friendly oasis. Not to mention, Gatlinburg sits beside Great Smoky Mountains National Park, so outdoor activities abound. Visitors recommend hiking trails like Grotto Falls and Laurel Falls to reach cascading waterfalls. If you're not a hiker, there are other ways to soak in the views. The Gatlinburg Aerial Tramway, which stretches for 2 miles, is an exciting way to get a panoramic look at the surrounding mountains.",
            price = 35.0
        ),
        Destination(
            id = "9",
            title = "Mount Fuji",
            imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Views_of_Mount_Fuji_from_%C5%8Cwakudani_20211202.jpg/800px-Views_of_Mount_Fuji_from_%C5%8Cwakudani_20211202.jpg",
            rating = 5.0f,
            location = "Japan",
            description = "Mount Fuji (富士山, Fujisan, Japanese: [ɸɯꜜ(d)ʑisaɴ] (listen)), or Fugaku, located on the island of Honshū, is the highest mountain in Japan, with a summit elevation of 3,776.24 m (12,389 ft 3 in). It is the second-highest volcano located on an island in Asia (after Mount Kerinci on the island of Sumatra), and seventh-highest peak of an island on Earth. Mount Fuji is an active stratovolcano that last erupted from 1707 to 1708. The mountain is located about 100 km (62 mi) southwest of Tokyo and is visible from there on clear days. Mount Fuji's exceptionally symmetrical cone, which is covered in snow for about five months of the year, is commonly used as a cultural icon of Japan and it is frequently depicted in art and photography, as well as visited by sightseers and climbers.",
            price = 150.0
        ),
        Destination(
            id = "10",
            title = "Mount Bromo",
            imageUrl = "https://upload.wikimedia.org/wikipedia/commons/8/8e/Bromo-Semeru-Batok-Widodaren.jpg",
            rating = 5.0f,
            location = "Indonesia",
            description = "The Bromo, or Mount Bromo (Javanese: ꦒꦸꦤꦸꦁ\u200Bꦧꦿꦩ Pegon: ڮنڠ برومو\u200E, romanized: Gunung Bromo) is an active somma volcano and part of the Tengger mountains, in East Java, Indonesia. At 2,329 meters (7,641 ft) it is not the highest peak of the massif, but the most famous. The area is one of the most visited tourist destinations in East Java, and the volcano is included in the Bromo Tengger Semeru National Park. The name Bromo comes from the Javanese pronunciation of Brahma, the Hindu god of creation. Mount Bromo is located in the middle of a plain called \"Sea of Sand\" (Javanese: Segara Wedi or Indonesian: Lautan Pasir), a nature reserve that has been protected since 1919.",
            price = 100.0
        )
    )
}