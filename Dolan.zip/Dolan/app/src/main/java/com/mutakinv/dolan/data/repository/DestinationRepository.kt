package com.mutakinv.dolan.data.repository

import com.mutakinv.dolan.data.models.Destination
import com.mutakinv.dolan.data.models.FakeDestinationDataSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class DestinationRepository {

    private val destinations = mutableListOf<Destination>()

    init {
        if (destinations.isEmpty()) {
            FakeDestinationDataSource.dummyDestinations.forEach {
                destinations.add(it)
            }
        }
    }

    fun getAllDestinations(): Flow<List<Destination>> {
        return flowOf(destinations)
    }

    fun getDestinationById(destinationId: String): Destination {
        return destinations.first {
            it.id == destinationId
        }
    }

    companion object {
        @Volatile
        private var instance: DestinationRepository? = null

        fun getInstance(): DestinationRepository =
            instance ?: synchronized(this) {
                DestinationRepository().apply {
                    instance = this
                }
            }
    }
}