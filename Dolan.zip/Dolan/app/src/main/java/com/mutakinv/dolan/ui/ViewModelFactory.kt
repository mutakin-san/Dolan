package com.mutakinv.dolan.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.mutakinv.dolan.data.repository.DestinationRepository
import com.mutakinv.dolan.ui.screen.detail.DetailDestinationViewModel
import com.mutakinv.dolan.ui.screen.home.HomeViewModel

class ViewModelFactory(private val repository: DestinationRepository) :
    ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            return HomeViewModel(repository) as T
        } else if (modelClass.isAssignableFrom(DetailDestinationViewModel::class.java)) {
            return DetailDestinationViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }
}