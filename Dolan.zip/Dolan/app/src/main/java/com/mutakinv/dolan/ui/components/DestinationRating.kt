package com.mutakinv.dolan.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import com.gowtham.ratingbar.RatingBar
import com.gowtham.ratingbar.RatingBarConfig


@Composable
fun DestinationRating(rating: Float, iconSize: Dp, fontSize: TextUnit, textColor: Color, modifier: Modifier = Modifier) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        RatingBar(
            value = rating,
            config = RatingBarConfig()
                .activeColor(Color(0xffF4D150))
                .isIndicator(true)
                .size(iconSize)
                .numStars(5),

            onValueChange = {},
            onRatingChanged = {},
        )
        Text(
            "$rating",
            style = MaterialTheme.typography.caption.copy(
                color = textColor,
                fontSize = fontSize
            ),
            modifier = Modifier.padding(start = 5.dp)
        )
    }
}