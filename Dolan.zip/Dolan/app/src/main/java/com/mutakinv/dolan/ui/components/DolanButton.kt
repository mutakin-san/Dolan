package com.mutakinv.dolan.ui.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.mutakinv.dolan.ui.theme.PurpleSecondary

@Composable
fun DolanButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Button(
        colors = ButtonDefaults.buttonColors(
            backgroundColor = PurpleSecondary,
            contentColor = Color.White
        ),
        shape = CircleShape,
        onClick = onClick,
        modifier = modifier
    ) {
        content(this)
    }
}

@Preview
@Composable
fun DolanButtonPreview() {
    DolanButton(onClick = { /*TODO*/ }) {
        
    }
}