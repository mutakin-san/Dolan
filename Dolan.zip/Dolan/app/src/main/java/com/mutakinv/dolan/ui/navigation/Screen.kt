package com.mutakinv.dolan.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("/home")
    object Detail : Screen("/detail-destination/{destinationId}") {
        fun createRoute(id: String) = "/detail-destination/$id"
    }
    object About : Screen("/about")

}