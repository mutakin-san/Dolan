package com.mutakinv.dolan.ui.screen.about

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.mutakinv.dolan.R
import com.mutakinv.dolan.ui.theme.Purple200

@Composable
fun AboutScreen(navigateBack: () -> Unit, modifier: Modifier = Modifier) {
    Scaffold { innerPadding ->
        Box {
            Column(modifier.padding(innerPadding)) {
                Image(
                    painterResource(id = R.drawable.profile),
                    contentDescription = "Personal Profile Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(480.dp)
                        .clip(RoundedCornerShape(bottomStart = 37.dp, bottomEnd = 37.dp))
                )
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text("Hi,\nI'm Mutakin", style = MaterialTheme.typography.h4.copy(Color.Black))
                    Text(
                        "Informatics engineering student from Tasikmalaya, has a high interest in Android Application Development",
                        Modifier.padding(vertical = 16.dp)
                    )

                    Row {
                        Icon(Icons.Outlined.Email, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("mutakin.email@gmail.com")

                    }

                }

            }
            IconButton(onClick = navigateBack, modifier = Modifier.padding(16.dp).clip(CircleShape).background(
                Purple200
            )) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Navigate Back", modifier.size(24.dp), tint = Color.White)
            }

        }
    }
}


@Preview
@Composable
fun AboutScreenPreview() {
    AboutScreen(navigateBack = {})
}