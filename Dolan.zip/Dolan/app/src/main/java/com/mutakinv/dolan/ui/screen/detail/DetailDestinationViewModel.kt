package com.mutakinv.dolan.ui.screen.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mutakinv.dolan.data.models.Destination
import com.mutakinv.dolan.data.repository.DestinationRepository
import com.mutakinv.dolan.ui.common.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DetailDestinationViewModel(
    private val repository: DestinationRepository
) : ViewModel() {
    private val _uiState: MutableStateFlow<UiState<Destination>> =
        MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<Destination>>
        get() = _uiState

    fun getDestinationById(destinationId: String) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            _uiState.value = UiState.Success(repository.getDestinationById(destinationId))
        }
    }
}