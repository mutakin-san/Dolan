package com.mutakinv.dolan.ui.screen.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mutakinv.dolan.data.di.Injection
import com.mutakinv.dolan.ui.ViewModelFactory
import com.mutakinv.dolan.ui.components.DestinationRating
import com.mutakinv.dolan.ui.components.DolanButton
import com.mutakinv.dolan.ui.theme.DolanTheme
import com.mutakinv.dolan.ui.theme.Purple200
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mutakinv.dolan.ui.common.UiState


@Composable
fun DetailScreen(
    modifier: Modifier = Modifier,
    destinationId: String,
    navigateBack: () -> Unit,
    viewModel: DetailDestinationViewModel = viewModel(
        factory = ViewModelFactory(Injection.provideRepository())
    ),
) {
    Scaffold(
        modifier = modifier
    ) { innerPadding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {

            viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
                when (uiState) {
                    is UiState.Loading -> {
                        viewModel.getDestinationById(destinationId)
                    }
                    is UiState.Success -> {
                        val data = uiState.data
                        DetailContent(
                            title = data.title,
                            imageUrl = data.imageUrl,
                            rating = data.rating,
                            location = data.location,
                            description = data.description,
                            price = data.price,
                            navigateBack = navigateBack
                        )
                    }
                    is UiState.Error -> {}
                }
            }
        }

    }
}


@Composable
fun DetailContent(
    title: String,
    imageUrl: String,
    rating: Float,
    location: String,
    description: String,
    price: Double,
    navigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize()) {
        val screenHeight = LocalConfiguration.current.screenHeightDp.dp
        AsyncImage(
            model = imageUrl,
            contentDescription = title,
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight.times(0.4f))
                .background(Color.LightGray),
            contentScale = ContentScale.FillBounds,
        )

        IconButton(
            onClick = navigateBack,
            modifier = Modifier
                .padding(16.dp)
                .clip(CircleShape)
                .background(Purple200)
        ) {
            Icon(
                Icons.Rounded.ArrowBack,
                contentDescription = "Navigate Back",
                modifier.size(24.dp),
                tint = Color.White
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(37.dp))
                .background(Color.White)
                .fillMaxWidth()
                .height(screenHeight.times(0.7f))
                .align(Alignment.BottomCenter)
                .padding(start = 30.dp, end = 30.dp, top = 41.dp)
                .offset(y = (-8).dp)
        ) {
            Column(
                horizontalAlignment = Alignment.Start,
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())

            ) {
                Text(title, style = MaterialTheme.typography.h4.copy(color = Color.Black))
                Row {
                    Icon(
                        Icons.Outlined.LocationOn,
                        contentDescription = "Location",
                        Modifier.size(14.dp)
                    )
                    Text(
                        location,
                        style = MaterialTheme.typography.caption.copy(fontSize = 12.sp),
                        modifier = Modifier
                    )
                }

                DestinationRating(
                    rating = rating,
                    iconSize = 12.dp,
                    fontSize = 13.sp,
                    textColor = Color.Black,
                    modifier = Modifier.padding(top = 9.dp)
                )


                var totalDays by remember {
                    mutableStateOf(0)
                }

                DayOfBooking(
                    day = totalDays,
                    onDecrement = { day ->
                        if (day != 0) totalDays = day - 1
                    }, onIncrement = { day ->
                        totalDays = day + 1
                    }
                )



                Text(
                    "Description",
                    style = MaterialTheme.typography.h5,
                    modifier = Modifier.padding(bottom = 18.dp)
                )
                Text(description, modifier = Modifier.padding(bottom = 80.dp))
            }



            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(top = 16.dp, bottom = 8.dp)
                    .align(Alignment.BottomCenter)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "\$${price}",
                        style = MaterialTheme.typography.body1.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colors.primary
                        )
                    )
                    Text(
                        "/Package",
                        style = MaterialTheme.typography.body2.copy(color = MaterialTheme.colors.primary)
                    )
                }


                DolanButton(onClick = { /*TODO*/ }) {
                    Text("Book Now", style = MaterialTheme.typography.h6)
                }
            }
        }


    }

}


@Composable
fun DayOfBooking(day: Int, onDecrement: (Int) -> Unit, onIncrement: (Int) -> Unit) {

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 28.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xffF3F3F3))
        ) {
            DolanButton(
                onClick = { onDecrement(day) },
            ) {
                Text("-", style = MaterialTheme.typography.h6)
            }

            Text(
                "$day",
                style = MaterialTheme.typography.body1,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            DolanButton(
                onClick = { onIncrement(day) },
            ) {
                Text("+", style = MaterialTheme.typography.h6)
            }
        }


        Text(
            "$day Days",
            style = MaterialTheme.typography.body1.copy(fontWeight = FontWeight.SemiBold),
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun DetailScreenPreview() {
    DolanTheme {
        DetailScreen(destinationId = "1", navigateBack = {})
    }
}