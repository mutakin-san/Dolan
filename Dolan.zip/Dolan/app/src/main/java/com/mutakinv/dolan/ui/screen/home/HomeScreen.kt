package com.mutakinv.dolan.ui.screen.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mutakinv.dolan.R
import com.mutakinv.dolan.data.di.Injection
import com.mutakinv.dolan.data.models.Destination
import com.mutakinv.dolan.ui.ViewModelFactory
import com.mutakinv.dolan.ui.components.DestinationGridItem
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mutakinv.dolan.ui.common.UiState

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    navigateToDetail: (String) -> Unit,
    navigateToAboutPage: () -> Unit,
    onFavorite: (String) -> Unit,
    viewModel: HomeViewModel = viewModel(factory = ViewModelFactory(Injection.provideRepository()))
) {

    viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
        when (uiState) {
            is UiState.Loading -> {
                viewModel.getAllDestinations()
            }
            is UiState.Success -> {
                HomeContent(
                    navigateToAboutPage = navigateToAboutPage,
                    navigateToDetail = navigateToDetail,
                    onFavorite = onFavorite,
                    destinations = uiState.data,
                    modifier = modifier
                )
            }
            is UiState.Error -> {}
        }
    }

}


@Composable
fun HomeContent(
    modifier: Modifier = Modifier,
    navigateToDetail: (String) -> Unit,
    navigateToAboutPage: () -> Unit,
    onFavorite: (String) -> Unit,
    destinations: List<Destination>
) {

    val scaffoldState = rememberScaffoldState()
    val scope = rememberCoroutineScope()

    Scaffold(
        scaffoldState = scaffoldState,
        topBar = {
            DolanTopAppBar(
                onMenuClick = {
                    scope.launch {
                        scaffoldState.drawerState.open()
                    }
                },
                onAvatarClick = navigateToAboutPage
            )
        },
        drawerGesturesEnabled = scaffoldState.drawerState.isOpen,
        drawerShape = RectangleShape,
        drawerElevation = 0.dp,
        drawerContent = {
            Row(modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    navigateToAboutPage()
                    scope.launch {
                        scaffoldState.drawerState.close()
                    }

                }
                .padding(horizontal = 8.dp, vertical = 16.dp)
                .semantics { this.contentDescription = "about_page" }) {
                Icon(Icons.Default.AccountBox, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("About Me", textAlign = TextAlign.Left)
            }
        },
        modifier = modifier.padding(horizontal = 16.dp)
    ) { innerPadding ->
        DestinationGrid(
            destinations = destinations,
            navigateToDetail,
            onFavorite,
            modifier = Modifier.padding(innerPadding)
        )

    }
}

@Composable
fun DolanTopAppBar(
    onMenuClick: () -> Unit,
    onAvatarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        backgroundColor = Color.White,
        elevation = 0.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {

            Icon(
                imageVector = Icons.Rounded.Menu,
                contentDescription = "Show Drawer Button",
                modifier = Modifier
                    .size(33.dp)
                    .clickable(onClick = onMenuClick)
            )

            Text(
                text = "Discover",
                style = MaterialTheme.typography.h3.copy(color = Color.Black),
            )
            Image(
                painterResource(R.drawable.avatar),
                contentDescription = "profile_picture",
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onAvatarClick)
            )
        }
    }
}


@Composable
fun DestinationGrid(
    destinations: List<Destination>,
    navigateToDetail: (String) -> Unit,
    onFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {

    LazyVerticalGrid(
        columns = GridCells.Adaptive(155.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 16.dp),
        modifier = modifier
    ) {
        items(destinations, key = { it.id }) { item ->
            DestinationGridItem(
                id = item.id,
                title = item.title,
                imageUrl = item.imageUrl,
                rating = item.rating,
                onClick = navigateToDetail,
                onFavoriteClick = onFavorite
            )
        }
    }

}