package com.mutakinv.dolan.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xC96A62B7)
val Purple500 = Color(0xFF6A62B7)
val Purple700 = Color(0xFF403A7A)
val PurpleSecondary = Color(0xFF897CFF)
