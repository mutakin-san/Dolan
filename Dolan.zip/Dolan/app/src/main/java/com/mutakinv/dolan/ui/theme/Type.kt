package com.mutakinv.dolan.ui.theme

import androidx.compose.material.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.mutakinv.dolan.R


val merriWeatherFonts = FontFamily(
    Font(R.font.merriweather_black, weight = FontWeight.Black),
    Font(R.font.merriweather_bold, weight = FontWeight.Bold),
    Font(R.font.merriweather_regular, weight = FontWeight.Normal),
)


val sourceSansProFonts = FontFamily(
    Font(R.font.sourcesanspro_black, weight = FontWeight.Black),
    Font(R.font.sourcesanspro_bold, weight = FontWeight.Bold),
    Font(R.font.sourcesanspro_semibold, weight = FontWeight.SemiBold),
    Font(R.font.sourcesanspro_regular, weight = FontWeight.Normal),
)

// Set of Material typography styles to start with
val Typography = Typography(
    body1 = TextStyle(
        fontFamily = sourceSansProFonts,
        fontWeight = FontWeight.Normal,
        fontSize = 18.sp
    ),
    body2 = TextStyle(
        fontFamily = sourceSansProFonts,
        fontWeight = FontWeight.Normal,
        fontSize = 18.sp
    ),
    caption = TextStyle(
        fontFamily = sourceSansProFonts,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
    ),
    h1 = TextStyle(
        fontFamily = merriWeatherFonts,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
    ),
    h3 = TextStyle(
        fontFamily = merriWeatherFonts,
        fontWeight = FontWeight.Normal,
        fontSize = 27.sp,
    ),
    h4 = TextStyle(
        fontFamily = merriWeatherFonts,
        fontWeight = FontWeight.Black,
        fontSize = 24.sp,
    ),
    h5 = TextStyle(
        fontFamily = merriWeatherFonts,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
    ),
    h6 = TextStyle(
        fontFamily = merriWeatherFonts,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
    ),

    /* Other default text styles to override
    button = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W500,
        fontSize = 14.sp
    ),
    caption = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp
    )
    */
)